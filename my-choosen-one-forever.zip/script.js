const messagesDiv = document.getElementById("messages");
const input = document.getElementById("messageInput");

function sendMessage() {
  if (input.value.trim() === "") return;
  const msg = document.createElement("div");
  msg.textContent = input.value;
  messagesDiv.appendChild(msg);
  input.value = "";
  messagesDiv.scrollTop = messagesDiv.scrollHeight;
}
